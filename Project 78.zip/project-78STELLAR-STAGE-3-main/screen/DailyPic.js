import React,{Component} from 'react'
import {View,Text} from 'react-native'

export default class DailyPicScreen extends Component{
    render(){
        return(
            <View>
               <Text>DailyPic</Text>

            </View>
        )
    }
}