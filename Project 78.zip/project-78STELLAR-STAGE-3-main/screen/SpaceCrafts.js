import React,{Component} from 'react'
import {View,Text} from 'react-native'

export default class SpaceCraftsScreen extends Component{
    render(){
        return(
            <View>
               <Text>Space Crafts</Text>

            </View>
        )
    }
}